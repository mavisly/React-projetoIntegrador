interface User {
    id: number;
    nome: string;
    usuario: string;
    email:string;
    senha: string;
    foto: string;
}

export default User;