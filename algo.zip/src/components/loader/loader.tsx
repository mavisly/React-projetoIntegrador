import { CircularProgress } from "@mui/material";


function Loader () {
    return(
        
        <div>
<CircularProgress className="carregamento" />

        </div>
        
       
        ) 
    

}

export default Loader;