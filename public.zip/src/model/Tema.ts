interface Tema{
    id: number;
    nome: string;
    descricao: string;
}
export default Tema;